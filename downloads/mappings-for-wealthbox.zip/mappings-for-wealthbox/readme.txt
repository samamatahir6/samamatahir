=== Mappings for Wealthbox ===
Contributors: samamatahir
Tags: gravity forms, wealthbox, crm, leads, contacts
Requires at least: 6.0
Tested up to: 7.1
Requires PHP: 8.0
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Send every Gravity Forms submission straight into Wealthbox CRM as a contact. No Zapier, no CSV exports, no copy and paste.

== Description ==

Mappings for Wealthbox connects Gravity Forms to Wealthbox CRM. Pick a form, choose which Wealthbox field each form field goes to, and publish. From then on, every new submission creates a contact in Wealthbox.

It is built for financial advisors, RIAs and the agencies that run their websites.

= Features =

* Map any Gravity Form to Wealthbox, one mapping per form
* Standard contact fields: first, last and middle name, nickname, job title, company, email, phone and background information
* File uploads are sent as links, checkboxes and multi selects one per line, consent with its full text
* Map hidden fields such as UTM tags and user IDs
* Duplicate a mapping in one click
* Test your Wealthbox connection before any lead is sent
* Developer hooks to change the payload, add tags and more

= Mappings for Wealthbox Pro =

[Pro](https://samamatahir.com/products/mappings-for-wealthbox/) is a separate add-on that adds Wealthbox custom fields with auto matching, update or create and update by email or phone, sync logs with the full request and response, and GP Nested Forms support.

= Documentation =

Full documentation: [samamatahir.com/products/mappings-for-wealthbox/docs/](https://samamatahir.com/products/mappings-for-wealthbox/docs/)

== External services ==

This plugin connects to the Wealthbox CRM API (https://api.crmworkspace.com/v1) to create contacts. It is needed for the plugin's only purpose: sending form submissions to your Wealthbox account.

* When: each time a visitor submits a Gravity Form that has a published mapping, and when you click Test connection in the settings.
* What is sent: the values of the form fields you mapped (for example name, email and phone), plus your Wealthbox access token for authentication.
* Nothing is sent until you add your own access token and publish a mapping.

Wealthbox terms of service: https://www.wealthbox.com/terms-of-service/
Wealthbox privacy policy: https://www.wealthbox.com/privacy-policy/

Mappings for Wealthbox is an independent plugin. It is not made or endorsed by Wealthbox or Rocketgenius (Gravity Forms).

== Installation ==

1. Install and activate Gravity Forms.
2. Upload the plugin through Plugins > Add New > Upload Plugin, or search for it in the plugin directory, then activate it.
3. In Wealthbox, open Settings > API Access and create an access token.
4. In WordPress, go to Wealthbox > Settings, paste the token and save. Use Connection & Cache > Test connection to check it.
5. Go to Wealthbox > Mappings > Add New, pick your form, map the fields and publish.

== Frequently Asked Questions ==

= Do I need Zapier or another automation tool? =

No. The plugin talks to the Wealthbox API directly from your WordPress site.

= Does it send old form entries? =

No. Only submissions made after you publish a mapping are sent.

= What happens if no name is mapped? =

Wealthbox needs a name, so the contact is saved as "Web Lead".

= Can it update contacts that already exist? =

The free plugin creates new contacts. Updating existing contacts is part of Mappings for Wealthbox Pro.

== Changelog ==

= 1.0.0 =
* First release: native field mapping, create only sync, value formatting, duplicate mapping, connection test.
