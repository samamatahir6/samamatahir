/* global jQuery, wbmAdmin */
( function ( $ ) {
	'use strict';

	function applyHiddenToggle() {
		var show = $( '#wbm_show_hidden' ).is( ':checked' );
		$( '.wbm-row-hidden' ).toggle( show );
	}

	function initSelect2() {
		if ( ! $.fn.select2 ) { return; }
		$( '.wbm-wb-field' ).each( function () {
			var $s = $( this );
			if ( $s.hasClass( 'select2-hidden-accessible' ) ) {
				$s.select2( 'destroy' );
			}
			$s.select2( { width: '100%' } );
		} );
	}

	function fetchFields( formId ) {
		return $.post( wbmAdmin.ajaxUrl, {
			action: 'wbm_form_fields',
			nonce: wbmAdmin.nonce,
			form_id: formId
		} );
	}

	// Form changed: rebuild the mapping table.
	function onFormChange( formId ) {
		var $table = $( '#wbm-map-table' );

		if ( ! formId || '0' === String( formId ) ) {
			$table.html( '<p class="wbm-empty">Select a form to load its fields.</p>' );
			return;
		}

		$table.html( '<p class="wbm-empty">Loading…</p>' );

		fetchFields( formId ).done( function ( res ) {
			if ( res && res.success ) {
				$table.html( res.data.html );
				applyHiddenToggle();
				initSelect2();
			} else {
				$table.html( '<p class="wbm-empty">Could not load form fields.</p>' );
			}
		} ).fail( function () {
			$table.html( '<p class="wbm-empty">Request failed.</p>' );
		} );
	}

	$( function () {
		$( '#wbm_form_id' ).on( 'change', function () {
			onFormChange( $( this ).val() );
		} );

		$( '#wbm_show_hidden' ).on( 'change', applyHiddenToggle );
		applyHiddenToggle();

		initSelect2();
	} );
} )( jQuery );
