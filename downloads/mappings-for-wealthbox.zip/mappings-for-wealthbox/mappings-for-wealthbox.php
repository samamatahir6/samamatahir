<?php
/**
 * Plugin Name:       Mappings for Wealthbox
 * Plugin URI:        https://samamatahir.com
 * Description:       Maps Gravity Forms submissions to Wealthbox CRM contacts (create only) using the native contact fields. Upgrade to Mappings for Wealthbox Pro for custom fields, update / upsert, logs and Nested Forms.
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      8.0
 * Author:            Samama Tahir, Muhammad Ayaz
 * Author URI:        https://samamatahir.com
 * License:           GPL v2 or later
 * Text Domain:       mappings-for-wealthbox
 *
 * @package MappingsForWealthbox
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'WBM_VERSION', '1.0.0' );
define( 'WBM_FILE', __FILE__ );
define( 'WBM_DIR', plugin_dir_path( __FILE__ ) );
define( 'WBM_URL', plugin_dir_url( __FILE__ ) );
define( 'WBM_BASENAME', plugin_basename( __FILE__ ) );

/**
 * PSR-4 style autoloader for the MappingsForWealthbox namespace.
 *
 * MappingsForWealthbox\Api\Wealthbox_Client -> includes/Api/Wealthbox_Client.php
 */
spl_autoload_register(
	static function ( $class ) {
		$prefix   = 'MappingsForWealthbox\\';
		$base_dir = WBM_DIR . 'includes/';
		$len      = strlen( $prefix );

		if ( 0 !== strncmp( $prefix, $class, $len ) ) {
			return;
		}

		$relative = substr( $class, $len );
		$file     = $base_dir . str_replace( '\\', '/', $relative ) . '.php';

		if ( file_exists( $file ) ) {
			require $file;
		}
	}
);

/**
 * Boot the plugin once all plugins are loaded (so GFAPI is available).
 */
add_action(
	'plugins_loaded',
	static function () {
		\MappingsForWealthbox\Plugin::instance();
	}
);

