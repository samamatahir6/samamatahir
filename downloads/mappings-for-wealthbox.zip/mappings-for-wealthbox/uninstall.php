<?php
/**
 * Uninstall cleanup.
 *
 * Removes options and mapping posts. Runs only on plugin delete. The Pro add-on
 * removes its own tables and cache.
 *
 * @package MappingsForWealthbox
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

delete_option( 'wbm_settings' );

// Remove mapping posts and their meta.
$mappings = get_posts(
	[
		'post_type'      => 'wbm_mapping',
		'post_status'    => 'any',
		'numberposts'    => -1,
		'fields'         => 'ids',
	]
);
foreach ( $mappings as $mapping_id ) {
	wp_delete_post( (int) $mapping_id, true );
}
