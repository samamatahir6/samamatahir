# Mappings for Wealthbox (Free)

Maps Gravity Forms submissions to new Wealthbox CRM contacts using the native Contact fields.

**Free includes:** per-form field mapping to native fields (first/last/middle name, nickname, job title, company, email, phone, background) and create-only sync.

**Pro add-on** (`mappings-for-wealthbox-pro`) adds: Wealthbox custom fields in the mapping dropdown, update / upsert with an indexed identity lookup, sync logs, and GP Nested Forms support.

## Requirements

- WordPress 6.0+, PHP 8.0+
- Gravity Forms active
- A Wealthbox access token (Wealthbox → Settings → API Access)

## Setup

1. Activate. Open **Wealthbox → Settings**, paste the access token, confirm the base URL (`https://api.crmworkspace.com/v1`), save. Use **Connection & Cache → Test connection** to verify.
2. **Wealthbox → Mappings → Add New**: pick the Gravity Form and map each field to a Wealthbox native field. Publish.

Submissions to a mapped form now create a contact.

## Architecture

- `Api/Wealthbox_Client` — HTTP only (auth, verbs).
- `Resources/*` — `Wealthbox_Resource` interface + `Contact_Resource`.
- `Fields/Native_Fields`, `Fields/Form_Fields` — native field list and GF field flattening.
- `Sync/Submission_Handler` — the create-only orchestrator.
- `Admin/*` — menu, settings, CPT, metabox.

## Extension hooks (used by the Pro add-on)

| Hook | Type | Purpose |
| --- | --- | --- |
| `wbm_request_args` | filter | Modify outgoing HTTP args. |
| `wbm_contact_kind` | filter | `kind` for native email/phone (default `Personal`). |
| `wbm_contact_payload` | filter | Mutate the Contact payload before send. |
| `wbm_native_fields` | filter | Add native fields to the dropdown. |
| `wbm_resource` | filter | Swap the resource handler. |
| `wbm_before_sync` | action | Inspect the payload before the API call. |
| `wbm_after_sync` | action | After the sync (`$result, $log_id, $entry, $form, $mapping, $payload`; `$log_id` is 0 in free). |
| `wbm_run_action` | filter | Handle non-create actions (update / upsert). |
| `wbm_target_groups` | filter | Add groups to the Wealthbox field dropdown. |
| `wbm_suggest_target` | filter | Pre-select a target for a GF field. |
| `wbm_map_target` | filter | Handle non-native targets in the payload. |
| `wbm_form_field_rows` / `wbm_nested_value` | filter | Nested Forms rows / values. |
| `wbm_metabox_rows` / `wbm_save_mapping` | action | Extra mapping-screen rows and their saving. |
| `wbm_settings_general_rows` / `wbm_settings_tools_sections` / `wbm_sanitize_settings` | action / action / filter | Extend the Settings page. |
