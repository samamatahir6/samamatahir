<?php
/**
 * Contact resource implementation.
 *
 * @package MappingsForWealthbox
 */

namespace MappingsForWealthbox\Resources;

use MappingsForWealthbox\Api\Wealthbox_Client;
use MappingsForWealthbox\Fields\Native_Fields;

/**
 * Maps a Gravity Forms entry into a Wealthbox Contact and creates/updates it.
 *
 * Fields mapped to a native Contact field are sent as that property. Any other
 * target (custom fields) and nested values are handled by add-ons through the
 * wbm_map_target and wbm_nested_value filters. Values are sent exactly as
 * Gravity Forms provides them.
 */
class Contact_Resource implements Wealthbox_Resource {

	/**
	 * Default kind for native email/phone/address array items.
	 *
	 * Filterable via 'wbm_contact_kind'.
	 */
	private const DEFAULT_KIND = 'Personal';

	/**
	 * API client.
	 *
	 * @var Wealthbox_Client
	 */
	private Wealthbox_Client $client;

	/**
	 * @param Wealthbox_Client|null $client Injected for testability.
	 */
	public function __construct( ?Wealthbox_Client $client = null ) {
		$this->client = $client ?? new Wealthbox_Client();
	}

	/**
	 * {@inheritDoc}
	 */
	public function document_type(): string {
		return 'Contact';
	}

	/**
	 * {@inheritDoc}
	 */
	public function endpoint(): string {
		return 'contacts';
	}

	/**
	 * {@inheritDoc}
	 */
	public function build_payload( array $entry, array $form, array $mapping ): array {
		$kind    = (string) apply_filters( 'wbm_contact_kind', self::DEFAULT_KIND, $entry, $form );
		$map     = $mapping['field_map'] ?? [];
		$state   = [
			'native' => [],
			'emails' => [],
			'phones' => [],
			'custom' => [],
		];

		foreach ( $map as $gf_key => $wb_target ) {
			$wb_target = (string) $wb_target;
			if ( '0' === $wb_target || '' === $wb_target ) {
				continue; // Unmapped row.
			}

			$gf_key = (string) $gf_key;

			// Resolve the value (nested rows come from an add-on; others read directly).
			if ( str_starts_with( $gf_key, 'nested:' ) ) {
				/**
				 * Resolve a nested (GP Nested Forms) key into a value. Empty without an add-on.
				 *
				 * @param string $value  Value so far.
				 * @param array  $entry  GF entry.
				 * @param array  $form   GF form.
				 * @param string $gf_key Nested field-map key.
				 */
				$value = (string) apply_filters( 'wbm_nested_value', '', $entry, $form, $gf_key );
			} else {
				$value = (string) rgar( $entry, $gf_key );
				$value = $this->maybe_format_file_upload( $gf_key, $value, $form );
				$value = $this->maybe_format_multi( $gf_key, $value, $entry, $form );
				$value = $this->maybe_format_consent( $gf_key, $value, $entry, $form );
			}

			if ( '' === $value ) {
				continue; // Nothing to send.
			}

			// Explicitly mapped to a Wealthbox native field.
			if ( Native_Fields::is_native( $wb_target ) ) {
				$this->apply_native( Native_Fields::key( $wb_target ), $value, $kind, $state['native'], $state['emails'], $state['phones'] );
				continue;
			}

			/**
			 * Handle a non-native target (e.g. a custom field id). Ignored without an add-on.
			 *
			 * @param array  $state     Keys: native, emails, phones, custom.
			 * @param string $wb_target Mapping target.
			 * @param string $gf_key    GF field key.
			 * @param string $value     Resolved, non-empty value.
			 * @param array  $form      GF form.
			 * @param string $kind      Kind for email/phone items.
			 */
			$state = (array) apply_filters( 'wbm_map_target', $state, $wb_target, $gf_key, $value, $form, $kind );
		}

		$payload = $state['native'];

		if ( $state['emails'] ) {
			$payload['email_addresses'] = $state['emails'];
		}
		if ( $state['phones'] ) {
			$payload['phone_numbers'] = $state['phones'];
		}
		if ( $state['custom'] ) {
			$payload['custom_fields'] = $state['custom'];
		}

		// Wealthbox requires a name; fall back so the record is not blank.
		if ( empty( $payload['first_name'] ) && empty( $payload['last_name'] ) ) {
			$payload['first_name'] = 'Web';
			$payload['last_name']  = 'Lead';
		}

		/**
		 * Filter the assembled Contact payload before it is sent.
		 *
		 * @param array $payload Contact payload.
		 * @param array $entry   GF entry.
		 * @param array $form    GF form.
		 * @param array $mapping Mapping config.
		 */
		return apply_filters( 'wbm_contact_payload', $payload, $entry, $form, $mapping );
	}

		/**
	 * Apply a value to a native Wealthbox contact property by key.
	 *
	 * @param string $key    Native property key (e.g. 'first_name', 'email').
	 * @param string $value  Value to set.
	 * @param string $kind   Kind for email/phone array items.
	 * @param array  $native By-ref scalar native fields.
	 * @param array  $emails By-ref email_addresses items.
	 * @param array  $phones By-ref phone_numbers items.
	 */
	private function apply_native( string $key, string $value, string $kind, array &$native, array &$emails, array &$phones ): void {
		switch ( $key ) {
			case 'email':
				$emails[] = [ 'address' => $value, 'kind' => $kind ];
				break;
			case 'phone':
				$phones[] = [ 'address' => $value, 'kind' => $kind ];
				break;
			case 'background':
				$native['background_info'] = $value;
				break;
			default:
				// first_name, last_name, middle_name, nickname, job_title, company_name, etc.
				$native[ $key ] = $value;
				break;
		}
	}

	/**
	 * Convert a File Upload field value into clean URL(s).
	 *
	 * Single-file fields store a plain URL. Multi-file fields store a JSON array
	 * of URLs. Returns one URL (single) or one URL per line (multi). Non-upload
	 * fields pass through unchanged.
	 *
	 * @param string $gf_key Field key.
	 * @param string $value  Raw entry value.
	 * @param array  $form   GF form.
	 * @return string
	 */
	private function maybe_format_file_upload( string $gf_key, string $value, array $form ): string {
		if ( '' === $value ) {
			return $value;
		}

		// Only act on fileupload fields.
		$field_id = (int) $gf_key; // '5' -> 5
		$is_upload = false;
		foreach ( (array) ( $form['fields'] ?? [] ) as $field ) {
			if ( (int) rgobj( $field, 'id' ) === $field_id && 'fileupload' === (string) rgobj( $field, 'type' ) ) {
				$is_upload = true;
				break;
			}
		}
		if ( ! $is_upload ) {
			return $value;
		}

		// Multi-file: value is a JSON array of URLs.
		$decoded = json_decode( $value, true );
		if ( is_array( $decoded ) ) {
			$urls = array_values( array_filter( array_map( 'trim', array_map( 'strval', $decoded ) ) ) );
			return implode( "\n", $urls );
		}

		// Single-file: already a plain URL string.
		return trim( $value );
	}

		/**
	 * Convert multi-value fields (checkbox, multiselect) into one value per line.
	 *
	 * Checkbox fields store each choice in a sub-input (id.1, id.2, ...).
	 * Multi Select fields store a JSON array. Both become newline-separated.
	 * Non-multi fields pass through unchanged.
	 *
	 * @param string $gf_key Field key.
	 * @param string $value  Raw entry value at the base key.
	 * @param array  $entry  GF entry (needed to read checkbox sub-inputs).
	 * @param array  $form   GF form.
	 * @return string
	 */
	private function maybe_format_multi( string $gf_key, string $value, array $entry, array $form ): string {
		// Only act on the base key (e.g. "33"), not a sub-input ("33.2").
		if ( str_contains( $gf_key, '.' ) ) {
			return $value;
		}

		$field_id = (int) $gf_key;
		$type     = '';
		foreach ( (array) ( $form['fields'] ?? [] ) as $field ) {
			if ( (int) rgobj( $field, 'id' ) === $field_id ) {
				$type = (string) rgobj( $field, 'type' );
				break;
			}
		}

		// Checkbox: collect all populated sub-inputs "id.x".
		if ( 'checkbox' === $type ) {
			$prefix = $gf_key . '.';
			$values = [];
			foreach ( $entry as $key => $val ) {
				if ( is_string( $key ) && str_starts_with( $key, $prefix ) ) {
					$val = trim( (string) $val );
					if ( '' !== $val ) {
						$values[] = $val;
					}
				}
			}
			return implode( "\n", $values );
		}

		// Multi Select: JSON array string.
		if ( 'multiselect' === $type ) {
			$decoded = json_decode( $value, true );
			if ( is_array( $decoded ) ) {
				$values = array_values( array_filter( array_map( 'trim', array_map( 'strval', $decoded ) ) ) );
				return implode( "\n", $values );
			}
		}

		return $value;
	}

	/**
	 * Format a Consent field into readable text: agreement status + the full
	 * consent text the user agreed to. Non-consent fields pass through unchanged.
	 *
	 * GF stores: id.1 = checkbox state, id.2 = label, id.3 = description text.
	 *
	 * @param string $gf_key Field key.
	 * @param string $value  Raw value at the base key.
	 * @param array  $entry  GF entry.
	 * @param array  $form   GF form.
	 * @return string
	 */
	private function maybe_format_consent( string $gf_key, string $value, array $entry, array $form ): string {
		if ( str_contains( $gf_key, '.' ) ) {
			return $value; // A specific sub-input was mapped; leave it.
		}

		$field_id = (int) $gf_key;
		$is_consent = false;
		foreach ( (array) ( $form['fields'] ?? [] ) as $field ) {
			if ( (int) rgobj( $field, 'id' ) === $field_id && 'consent' === (string) rgobj( $field, 'type' ) ) {
				$is_consent = true;
				break;
			}
		}
		if ( ! $is_consent ) {
			return $value;
		}

		$checked = trim( (string) rgar( $entry, $gf_key . '.1' ) );
		$text    = trim( (string) rgar( $entry, $gf_key . '.3' ) );
		$agreed  = ( '' !== $checked && '0' !== $checked );

		$status = $agreed
			? __( 'Consent given', 'mappings-for-wealthbox' )
			: __( 'Consent NOT given', 'mappings-for-wealthbox' );

		return '' !== $text ? $status . ": \n" . $text : $status;
	}



	/**
	 * {@inheritDoc}
	 */
	public function create( array $payload ): array {
		return $this->client->post( $this->endpoint(), $payload );
	}

	/**
	 * {@inheritDoc}
	 */
	public function update( int $id, array $payload ): array {
		return $this->client->put( $this->endpoint() . '/' . $id, $payload );
	}

	/**
	 * {@inheritDoc}
	 */
	public function extract_id( $body ): ?int {
		if ( is_array( $body ) && isset( $body['id'] ) ) {
			return (int) $body['id'];
		}
		return null;
	}
}
