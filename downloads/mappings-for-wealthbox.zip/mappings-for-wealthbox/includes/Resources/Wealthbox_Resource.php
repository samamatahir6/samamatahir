<?php
/**
 * Syncable Wealthbox resource contract.
 *
 * @package MappingsForWealthbox
 */

namespace MappingsForWealthbox\Resources;

/**
 * Every Wealthbox object the plugin can sync to (Contact today; Opportunity,
 * Project, etc. later) implements this interface. The submission engine talks
 * only to this contract, so adding a new object type is a new class — not an
 * edit to the engine.
 */
interface Wealthbox_Resource {

	/**
	 * The Wealthbox document type this resource represents (e.g. 'Contact').
	 */
	public function document_type(): string;

	/**
	 * The REST endpoint path for this resource (e.g. 'contacts').
	 */
	public function endpoint(): string;

	/**
	 * Build the API payload from a Gravity Forms entry using a saved mapping.
	 *
	 * @param array $entry   GF entry.
	 * @param array $form    GF form.
	 * @param array $mapping Saved mapping config for this form.
	 * @return array<string,mixed>
	 */
	public function build_payload( array $entry, array $form, array $mapping ): array;

	/**
	 * Create the resource in Wealthbox.
	 *
	 * @param array $payload Prepared payload.
	 * @return array{code:int,body:mixed,error:?string}
	 */
	public function create( array $payload ): array;

	/**
	 * Update the resource in Wealthbox.
	 *
	 * @param int   $id      Wealthbox record ID.
	 * @param array $payload Prepared payload.
	 * @return array{code:int,body:mixed,error:?string}
	 */
	public function update( int $id, array $payload ): array;

	/**
	 * Extract the created/updated record ID from an API response body.
	 *
	 * @param mixed $body Decoded response body.
	 * @return int|null
	 */
	public function extract_id( $body ): ?int;
}
