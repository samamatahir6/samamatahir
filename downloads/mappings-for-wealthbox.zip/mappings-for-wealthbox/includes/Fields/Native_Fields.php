<?php
/**
 * Wealthbox native (built-in) contact fields.
 *
 * @package MappingsForWealthbox
 */

namespace MappingsForWealthbox\Fields;

/**
 * The built-in Contact fields that aren't part of the custom-field catalog.
 * Each has a stable "native:{key}" identifier used in the mapping and routed
 * to the real Wealthbox property at send time.
 */
class Native_Fields {

	/**
	 * Native contact fields as id => label.
	 *
	 * The id is the value stored in the mapping; the label shows in the dropdown.
	 *
	 * @return array<string,string>
	 */
	public static function all(): array {
		$fields = [
			'native:first_name'   => __( 'First name', 'mappings-for-wealthbox' ),
			'native:last_name'    => __( 'Last name', 'mappings-for-wealthbox' ),
			'native:middle_name'  => __( 'Middle name', 'mappings-for-wealthbox' ),
			'native:nickname'     => __( 'Nickname', 'mappings-for-wealthbox' ),
			'native:job_title'    => __( 'Job title', 'mappings-for-wealthbox' ),
			'native:company_name' => __( 'Company name', 'mappings-for-wealthbox' ),
			'native:email'        => __( 'Email address', 'mappings-for-wealthbox' ),
			'native:phone'        => __( 'Phone number', 'mappings-for-wealthbox' ),
			'native:background'   => __( 'Background information', 'mappings-for-wealthbox' ),
		];

		/**
		 * Filter the native field list (add address parts, etc.).
		 *
		 * @param array $fields id => label pairs.
		 */
		return apply_filters( 'wbm_native_fields', $fields );
	}

	/**
	 * Whether a mapping value refers to a native field.
	 *
	 * @param string $id Mapping target id.
	 */
	public static function is_native( string $id ): bool {
		return str_starts_with( $id, 'native:' );
	}

	/**
	 * The native property key from a "native:key" id (e.g. 'first_name').
	 *
	 * @param string $id Mapping target id.
	 */
	public static function key( string $id ): string {
		return self::is_native( $id ) ? substr( $id, strlen( 'native:' ) ) : '';
	}
}