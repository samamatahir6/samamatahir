<?php
/**
 * Gravity Forms field flattening.
 *
 * @package MappingsForWealthbox
 */

namespace MappingsForWealthbox\Fields;

/**
 * Turns a GF form into individually-mappable rows.
 */
class Form_Fields {

	/**
	 * Flatten a GF form into mappable rows: parent fields plus each sub-input
	 * (Name -> First/Last, Address -> Street/City/State/Zip, etc.).
	 *
	 * Fields of type 'form' (GP Nested Forms) are passed to the
	 * wbm_form_field_rows filter, so an add-on can list their child fields.
	 *
	 * @param int $form_id GF form ID.
	 * @return array<int,array{key:string,label:string,nested:bool}>
	 */
	public static function flatten( int $form_id ): array {
		if ( ! class_exists( '\GFAPI' ) ) {
			return [];
		}

		$form = \GFAPI::get_form( $form_id );
		if ( empty( $form['fields'] ) ) {
			return [];
		}

		$rows = [];

		foreach ( $form['fields'] as $field ) {
			$id    = (string) rgobj( $field, 'id' );
			$label = (string) rgobj( $field, 'label' );
			$type  = (string) rgobj( $field, 'type' );

			if ( in_array( $type, [ 'page', 'section', 'html', 'captcha' ], true ) ) {
				continue;
			}

			if ( 'form' === $type ) {
				/**
				 * Rows for a GP Nested Forms field. Empty unless an add-on supplies them.
				 *
				 * @param array  $rows  Rows to add.
				 * @param mixed  $field The parent (type=form) GF field.
				 * @param string $label Parent field label.
				 */
				foreach ( (array) apply_filters( 'wbm_form_field_rows', [], $field, $label ) as $child_row ) {
					$rows[] = $child_row;
				}
				continue;
			}

			// Parent row (combined value).
			$rows[] = [
				'key'       => $id,
				'label'     => $label,
				'nested'    => false,
				'is_hidden' => ( 'hidden' === $type ),
			];

			// Checkbox / Multi Select are collapsed into one combined value, so
			// don't list their individual choice sub-inputs — map the parent row.
			if ( in_array( $type, [ 'checkbox', 'multiselect' ], true ) ) {
				continue;
			}

			// Sub-inputs, listed independently.
			$inputs = rgobj( $field, 'inputs' );
			if ( is_array( $inputs ) ) {
				foreach ( $inputs as $input ) {
					if ( ! empty( $input['isHidden'] ) ) {
						continue;
					}
					$rows[] = [
						'key'    => (string) $input['id'],
						'label'  => $label . ' — ' . (string) ( $input['label'] ?? $input['id'] ),
						'nested' => false,
					];
				}
			}
		}

		return $rows;
	}
}
