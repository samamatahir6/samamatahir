<?php
/**
 * Settings accessor.
 *
 * @package MappingsForWealthbox
 */

namespace MappingsForWealthbox\Support;

/**
 * Central, read-only-ish accessor for plugin options so no other class
 * has to know the option name or shape.
 */
class Settings {

	public const OPTION_NAME = 'wbm_settings';

	public const DEFAULT_BASE_URL = 'https://api.crmworkspace.com/v1';

	/**
	 * Full settings array with defaults applied.
	 *
	 * @return array{token:string,base_url:string}
	 */
	public static function all(): array {
		$stored = get_option( self::OPTION_NAME, [] );
		if ( ! is_array( $stored ) ) {
			$stored = [];
		}

		return [
			'token'    => (string) ( $stored['token'] ?? '' ),
			'base_url' => (string) ( $stored['base_url'] ?? self::DEFAULT_BASE_URL ),
		];
	}

	/**
	 * The Wealthbox access token.
	 */
	public static function token(): string {
		return self::all()['token'];
	}

	/**
	 * The API base URL (never with a trailing slash).
	 */
	public static function base_url(): string {
		return untrailingslashit( self::all()['base_url'] ?: self::DEFAULT_BASE_URL );
	}

	/**
	 * True when we have enough to talk to the API.
	 */
	public static function is_configured(): bool {
		return '' !== self::token() && '' !== self::base_url();
	}
}
