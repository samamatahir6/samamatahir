<?php
/**
 * Plugin orchestrator.
 *
 * @package MappingsForWealthbox
 */

namespace MappingsForWealthbox;

use MappingsForWealthbox\Admin\Menu;
use MappingsForWealthbox\Admin\Settings_Page;
use MappingsForWealthbox\Admin\Mapping_CPT;
use MappingsForWealthbox\Admin\Mapping_Metabox;
use MappingsForWealthbox\Sync\Submission_Handler;

/**
 * Wires the plugin together. Thin by design — each concern lives in its own class.
 */
final class Plugin {

	/**
	 * Singleton instance.
	 *
	 * @var Plugin|null
	 */
	private static ?Plugin $instance = null;

	/**
	 * Retrieve (and lazily build) the singleton.
	 */
	public static function instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
			self::$instance->boot();
		}
		return self::$instance;
	}

	/**
	 * Private constructor — use instance().
	 */
	private function __construct() {}

	/**
	 * Register all services and hooks.
	 */
	private function boot(): void {
		load_plugin_textdomain( 'mappings-for-wealthbox', false, dirname( WBM_BASENAME ) . '/languages' );

		// Admin UI.
		if ( is_admin() ) {
			new Menu();
			new Settings_Page();
			new Mapping_Metabox();
		}

		// CPT must register on front and back end.
		new Mapping_CPT();

		// The submission bridge (Gravity Forms -> Wealthbox).
		new Submission_Handler();
	}
}
