<?php
/**
 * Gravity Forms -> Wealthbox submission bridge.
 *
 * @package MappingsForWealthbox
 */

namespace MappingsForWealthbox\Sync;

use MappingsForWealthbox\Admin\Mapping_CPT;
use MappingsForWealthbox\Resources\Contact_Resource;
use MappingsForWealthbox\Resources\Wealthbox_Resource;

/**
 * Thin orchestrator: on submission it finds the mapping and delegates to a
 * resource. The free plugin only creates contacts; other actions are handed to
 * add-ons through the wbm_run_action filter.
 */
class Submission_Handler {

	public function __construct() {
		add_action( 'gform_after_submission', [ $this, 'handle' ], 10, 2 );
	}

	/**
	 * Handle a Gravity Forms submission.
	 *
	 * @param array $entry GF entry.
	 * @param array $form  GF form.
	 */
	public function handle( $entry, $form ): void {
		$form_id = (int) rgar( $form, 'id' );

		$mapping = Mapping_CPT::get_mapping_for_form( $form_id );
		if ( null === $mapping ) {
			return; // No mapping for this form: do nothing.
		}

		$resource = $this->resource_for( $mapping );
		$payload  = $resource->build_payload( $entry, $form, $mapping );

		/**
		 * Fires before the Wealthbox call. Last chance to inspect the payload.
		 *
		 * @param array               $payload  Prepared payload.
		 * @param array               $entry    GF entry.
		 * @param array               $form     GF form.
		 * @param array               $mapping  Mapping config.
		 * @param Wealthbox_Resource  $resource Resource handler.
		 */
		do_action( 'wbm_before_sync', $payload, $entry, $form, $mapping, $resource );

		$action = (string) ( $mapping['action'] ?? 'create' );

		if ( 'create' === $action ) {
			$result = self::do_create( $resource, $payload );
		} else {
			/**
			 * Run a non-create action (update / upsert). Return the normalized
			 * result array, or leave null when nothing handles the action.
			 *
			 * @param array|null         $result   Null until handled.
			 * @param string             $action   Mapping action.
			 * @param Wealthbox_Resource $resource Resource handler.
			 * @param array              $payload  Prepared payload.
			 * @param array              $entry    GF entry.
			 * @param array              $form     GF form.
			 * @param array              $mapping  Mapping config.
			 */
			$result = apply_filters( 'wbm_run_action', null, $action, $resource, $payload, $entry, $form, $mapping );

			if ( ! is_array( $result ) ) {
				return; // Not supported without the Pro add-on.
			}
		}

		/**
		 * Fires after the sync attempt. Add-ons use it for logging and identity indexing.
		 *
		 * @param array  $result  Normalized result.
		 * @param int    $log_id  Always 0 in the free plugin (it does not log).
		 * @param array  $entry   GF entry.
		 * @param array  $form    GF form.
		 * @param array  $mapping Mapping config.
		 * @param array  $payload Payload that was sent.
		 */
		do_action( 'wbm_after_sync', $result, 0, $entry, $form, $mapping, $payload );
	}

	/**
	 * Perform a create and normalize.
	 *
	 * @param Wealthbox_Resource $resource Resource.
	 * @param array              $payload  Payload.
	 * @return array{status:string,contact_id:?int,code:int,body:mixed,message:string}
	 */
	public static function do_create( Wealthbox_Resource $resource, array $payload ): array {
		$response   = $resource->create( $payload );
		$contact_id = $resource->extract_id( $response['body'] );
		$ok         = in_array( (int) $response['code'], [ 200, 201 ], true );

		return [
			'status'     => $ok ? 'created' : 'error',
			'contact_id' => $contact_id,
			'code'       => (int) $response['code'],
			'body'       => $response['body'],
			'message'    => $ok ? __( 'Contact created.', 'mappings-for-wealthbox' ) : (string) ( $response['error'] ?? __( 'Create failed.', 'mappings-for-wealthbox' ) ),
		];
	}

	/**
	 * Resolve the resource handler for a mapping.
	 *
	 * Contact-only today; new object types register via the filter below.
	 *
	 * @param array $mapping Mapping config.
	 */
	private function resource_for( array $mapping ): Wealthbox_Resource {
		$resource = new Contact_Resource();

		/**
		 * Filter the resource handler used for a mapping, to support future
		 * object types (Opportunity, Project, ...) without touching the engine.
		 *
		 * @param Wealthbox_Resource $resource Default (Contact) handler.
		 * @param array              $mapping  Mapping config.
		 */
		return apply_filters( 'wbm_resource', $resource, $mapping );
	}
}
