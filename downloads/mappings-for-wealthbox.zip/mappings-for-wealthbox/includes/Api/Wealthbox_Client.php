<?php
/**
 * Wealthbox REST client.
 *
 * @package MappingsForWealthbox
 */

namespace MappingsForWealthbox\Api;

use MappingsForWealthbox\Support\Settings;
use WP_Error;

/**
 * Thin HTTP wrapper around the Wealthbox API.
 *
 * Knows only about auth, verbs, pagination and response shape — nothing about
 * contacts, forms or mappings. Swap or extend this one class when the API changes.
 */
class Wealthbox_Client {

	/**
	 * Auth token.
	 *
	 * @var string
	 */
	private string $token;

	/**
	 * Base URL without trailing slash.
	 *
	 * @var string
	 */
	private string $base_url;

	/**
	 * @param string|null $token    Optional override; falls back to settings.
	 * @param string|null $base_url Optional override; falls back to settings.
	 */
	public function __construct( ?string $token = null, ?string $base_url = null ) {
		$this->token    = $token ?? Settings::token();
		$this->base_url = untrailingslashit( $base_url ?? Settings::base_url() );
	}

	/**
	 * GET a resource.
	 *
	 * @param string               $path  Path relative to base (e.g. 'contacts').
	 * @param array<string,mixed>  $query Query args.
	 * @return array{code:int,body:mixed,error:?string}
	 */
	public function get( string $path, array $query = [] ): array {
		$url = $this->url( $path );
		if ( $query ) {
			$url = add_query_arg( array_map( 'rawurlencode', array_map( 'strval', $query ) ), $url );
		}
		return $this->request( 'GET', $url );
	}

	/**
	 * POST a JSON body.
	 *
	 * @param string              $path Path relative to base.
	 * @param array<string,mixed> $body Payload.
	 * @return array{code:int,body:mixed,error:?string}
	 */
	public function post( string $path, array $body ): array {
		return $this->request( 'POST', $this->url( $path ), $body );
	}

	/**
	 * PUT a JSON body.
	 *
	 * @param string              $path Path relative to base.
	 * @param array<string,mixed> $body Payload.
	 * @return array{code:int,body:mixed,error:?string}
	 */
	public function put( string $path, array $body ): array {
		return $this->request( 'PUT', $this->url( $path ), $body );
	}

	/**
	 * Build a full URL for a path.
	 */
	private function url( string $path ): string {
		return $this->base_url . '/' . ltrim( $path, '/' );
	}

	/**
	 * Execute the request and normalize the response.
	 *
	 * @param string                   $method HTTP verb.
	 * @param string                   $url    Absolute URL.
	 * @param array<string,mixed>|null $body   Optional JSON body.
	 * @return array{code:int,body:mixed,error:?string}
	 */
	private function request( string $method, string $url, ?array $body = null ): array {
		if ( '' === $this->token ) {
			return [
				'code'  => 0,
				'body'  => null,
				'error' => __( 'No Wealthbox access token is configured.', 'mappings-for-wealthbox' ),
			];
		}

		$args = [
			'method'  => $method,
			'timeout' => 20,
			'headers' => [
				'ACCESS_TOKEN' => $this->token,
				'Content-Type' => 'application/json',
				'Accept'       => 'application/json',
			],
		];

		if ( null !== $body ) {
			$args['body'] = wp_json_encode( $body );
		}

		/**
		 * Filter the outgoing request args (add retries, tweak timeout, etc.).
		 *
		 * @param array  $args   wp_remote_request args.
		 * @param string $method HTTP method.
		 * @param string $url    Target URL.
		 */
		$args = apply_filters( 'wbm_request_args', $args, $method, $url );

		$response = wp_remote_request( $url, $args );

		if ( $response instanceof WP_Error ) {
			return [
				'code'  => 0,
				'body'  => null,
				'error' => $response->get_error_message(),
			];
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$raw  = wp_remote_retrieve_body( $response );
		$data = json_decode( $raw, true );

		return [
			'code'  => $code,
			'body'  => ( null === $data && '' !== $raw ) ? $raw : $data,
			'error' => ( $code >= 400 ) ? sprintf( /* translators: %d: HTTP status code. */ __( 'HTTP %d from Wealthbox.', 'mappings-for-wealthbox' ), $code ) : null,
		];
	}
}
