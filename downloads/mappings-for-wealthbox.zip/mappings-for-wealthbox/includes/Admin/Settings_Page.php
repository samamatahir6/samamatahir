<?php
/**
 * Settings submenu page.
 *
 * @package MappingsForWealthbox
 */

namespace MappingsForWealthbox\Admin;

use MappingsForWealthbox\Api\Wealthbox_Client;
use MappingsForWealthbox\Support\Settings;

/**
 * Renders and persists plugin settings. Add-ons extend it through the
 * wbm_settings_general_rows, wbm_settings_tools_sections and
 * wbm_sanitize_settings hooks.
 */
class Settings_Page {

	// private const PAGE_SLUG    = 'edit.php?post_type=' . Mapping_CPT::POST_TYPE;
	private const PAGE_SLUG    = 'wbm-settings';
	private const OPTION_GROUP = 'wbm_settings_group';

	public function __construct() {
		add_action( 'admin_menu', [ $this, 'add_page' ], 11 );
		add_action( 'admin_init', [ $this, 'register' ] );
		add_action( 'admin_post_wbm_test_connection', [ $this, 'handle_test' ] );
	}

	/**
	 * Add the Settings submenu under the Wealthbox menu.
	 */
	public function add_page(): void {
		add_submenu_page(
			Menu::SLUG,
			__( 'Wealthbox Settings', 'mappings-for-wealthbox' ),
			__( 'Settings', 'mappings-for-wealthbox' ),
			Menu::CAPABILITY,
			self::PAGE_SLUG,
			[ $this, 'render' ]
		);
	}

	/**
	 * Register the option and sanitizer.
	 */
	public function register(): void {
		register_setting(
			self::OPTION_GROUP,
			Settings::OPTION_NAME,
			[ 'sanitize_callback' => [ $this, 'sanitize' ] ]
		);
	}

	/**
	 * Sanitize submitted settings.
	 *
	 * @param mixed $input Raw input.
	 * @return array{token:string,base_url:string}
	 */
	public function sanitize( $input ): array {
		$input = is_array( $input ) ? $input : [];

		$base_url = esc_url_raw( trim( (string) ( $input['base_url'] ?? '' ) ) );

		$clean = [
			'token'    => sanitize_text_field( (string) ( $input['token'] ?? '' ) ),
			'base_url' => $base_url ?: Settings::DEFAULT_BASE_URL,
		];

		/**
		 * Filter the sanitized settings so add-ons can persist their own keys.
		 *
		 * @param array $clean Sanitized settings.
		 * @param array $input Raw submitted input.
		 */
		return (array) apply_filters( 'wbm_sanitize_settings', $clean, $input );
	}

	/**
	 * Render the settings page.
	 */
		/**
	 * Render the settings page with tabs.
	 */
	public function render(): void {
		if ( ! current_user_can( Menu::CAPABILITY ) ) {
			return;
		}

		$settings = Settings::all();

		// Active tab (default: general).
		$tab      = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'general'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$allowed  = [ 'general', 'tools' ];
		$tab      = in_array( $tab, $allowed, true ) ? $tab : 'general';
		$base_url = admin_url( 'admin.php?page=' . self::PAGE_SLUG );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Wealthbox Settings', 'mappings-for-wealthbox' ); ?></h1>

			<?php settings_errors(); ?>

			<h2 class="nav-tab-wrapper">
				<a href="<?php echo esc_url( add_query_arg( 'tab', 'general', $base_url ) ); ?>"
					class="nav-tab <?php echo 'general' === $tab ? 'nav-tab-active' : ''; ?>">
					<?php esc_html_e( 'General', 'mappings-for-wealthbox' ); ?>
				</a>
				<a href="<?php echo esc_url( add_query_arg( 'tab', 'tools', $base_url ) ); ?>"
					class="nav-tab <?php echo 'tools' === $tab ? 'nav-tab-active' : ''; ?>">
					<?php esc_html_e( 'Connection & Cache', 'mappings-for-wealthbox' ); ?>
				</a>
			</h2>

			<div class="wbm-tab-panel" style="max-width:760px;background:#fff;border:1px solid #dcdcde;border-top:none;padding:20px;">

			<?php if ( 'general' === $tab ) : ?>

				<form action="options.php" method="post">
					<?php settings_fields( self::OPTION_GROUP ); ?>
					<input type="hidden" name="_wp_http_referer" value="<?php echo esc_attr( add_query_arg( 'tab', 'general', $base_url ) ); ?>">
					<table class="form-table" role="presentation">
						<tr>
							<th scope="row"><label for="wbm_token"><?php esc_html_e( 'Access token', 'mappings-for-wealthbox' ); ?></label></th>
							<td>
								<input type="password" id="wbm_token" name="<?php echo esc_attr( Settings::OPTION_NAME ); ?>[token]" value="<?php echo esc_attr( $settings['token'] ); ?>" class="regular-text" autocomplete="off">
								<p class="description"><?php esc_html_e( 'Wealthbox → Settings → API Access. Sent as the ACCESS_TOKEN header.', 'mappings-for-wealthbox' ); ?></p>
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="wbm_base_url"><?php esc_html_e( 'Base URL', 'mappings-for-wealthbox' ); ?></label></th>
							<td>
								<input type="url" id="wbm_base_url" name="<?php echo esc_attr( Settings::OPTION_NAME ); ?>[base_url]" value="<?php echo esc_attr( $settings['base_url'] ); ?>" class="regular-text" placeholder="<?php echo esc_attr( Settings::DEFAULT_BASE_URL ); ?>">
							</td>
						</tr>
						<?php
						/**
						 * Add-on rows for the General settings table.
						 *
						 * @param array $settings Current settings.
						 */
						do_action( 'wbm_settings_general_rows', $settings );
						?>
					</table>
					<?php submit_button(); ?>
				</form>

			<?php else : ?>

				<h2><?php esc_html_e( 'Connection', 'mappings-for-wealthbox' ); ?></h2>
				<p class="description"><?php esc_html_e( 'Sends one authenticated request to Wealthbox to confirm the saved token and base URL work.', 'mappings-for-wealthbox' ); ?></p>
				<form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post" style="margin-bottom:24px;">
					<input type="hidden" name="action" value="wbm_test_connection">
					<?php wp_nonce_field( 'wbm_test_connection' ); ?>
					<?php submit_button( __( 'Test connection', 'mappings-for-wealthbox' ), 'secondary', 'submit', false ); ?>
				</form>

				<?php
				/**
				 * Add-on sections for the Connection tab.
				 */
				do_action( 'wbm_settings_tools_sections' );
				?>

			<?php endif; ?>

			</div>
		</div>
		<style>
			.nav-tab {
    			 margin-left: 0 !important;
    			 margin-right: 0.5em;
    			}
		</style>
		<?php
	}

	/**
	 * Handle the "Test connection" action: one authenticated GET to Wealthbox.
	 */
	public function handle_test(): void {
		if ( ! current_user_can( Menu::CAPABILITY ) ) {
			wp_die( esc_html__( 'Insufficient permissions.', 'mappings-for-wealthbox' ) );
		}
		check_admin_referer( 'wbm_test_connection' );

		if ( ! Settings::is_configured() ) {
			$this->flash_notice(
				'wbm_test',
				__( 'Add a token and base URL first, then save, before testing.', 'mappings-for-wealthbox' ),
				'error'
			);
			$this->redirect_back();
		}

		// Cheapest authenticated call: one contact.
		$response = ( new Wealthbox_Client() )->get( 'contacts', [ 'per_page' => 1 ] );
		$code     = (int) $response['code'];

		if ( 200 === $code ) {
			$this->flash_notice(
				'wbm_test',
				__( 'Success — Wealthbox accepted the token. Connection is working.', 'mappings-for-wealthbox' ),
				'updated'
			);
		} elseif ( 401 === $code || 403 === $code ) {
			$this->flash_notice(
				'wbm_test',
				sprintf(
					/* translators: %d: HTTP status code. */
					__( 'Authentication failed (HTTP %d). Check the access token.', 'mappings-for-wealthbox' ),
					$code
				),
				'error'
			);
		} else {
			$detail = $response['error'] ? $response['error'] : sprintf( /* translators: %d: HTTP status code. */ __( 'Unexpected response (HTTP %d).', 'mappings-for-wealthbox' ), $code );
			$this->flash_notice( 'wbm_test', $detail, 'error' );
		}

		$this->redirect_back();
	}

	/**
	 * Store a settings notice that survives the redirect.
	 *
	 * @param string $code    Notice code.
	 * @param string $message Message text.
	 * @param string $type    'updated' | 'error'.
	 */
	private function flash_notice( string $code, string $message, string $type ): void {
		add_settings_error( 'wbm_settings', $code, $message, $type );
		set_transient( 'settings_errors', get_settings_errors(), 30 );
	}

	/**
	 * Redirect back to the settings page.
	 */
	private function redirect_back(): void {
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::PAGE_SLUG . '&settings-updated=1' ) );
		exit;
	}
}
