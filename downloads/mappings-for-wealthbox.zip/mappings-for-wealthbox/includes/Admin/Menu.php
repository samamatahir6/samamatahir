<?php
/**
 * Top-level admin menu.
 *
 * @package MappingsForWealthbox
 */

namespace MappingsForWealthbox\Admin;

/**
 * Registers the parent "Wealthbox" menu. Submenu pages (Settings, Logs) and the
 * CPT hang off this slug from their own classes.
 */
class Menu {

	public const SLUG = 'edit.php?post_type=' . Mapping_CPT::POST_TYPE;
	// public const SLUG = 'wealthbox';

	public const CAPABILITY = 'manage_options';

	public function __construct() {
		add_action( 'admin_menu', [ $this, 'register' ], 9 );
		add_action( 'admin_menu', [ $this, 'relabel_first_submenu' ], 999 );
	}

	/**
	 * Register the parent menu with a dashboard landing page.
	 */
	public function register(): void {
		add_menu_page(
			__( 'Wealthbox', 'mappings-for-wealthbox' ),
			__( 'Wealthbox', 'mappings-for-wealthbox' ),
			self::CAPABILITY,
			self::SLUG,
			'',
			'dashicons-networking',
			58
		);
	}

	/**
	 * Simple landing page pointing to the main areas.
	 */
	public function render_landing(): void {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			return;
		}
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Mappings for Wealthbox', 'mappings-for-wealthbox' ); ?></h1>
			<p><?php esc_html_e( 'Connect Gravity Forms submissions to Wealthbox CRM.', 'mappings-for-wealthbox' ); ?></p>
			<ul class="ul-disc">
				<li><a href="<?php echo esc_url( admin_url( 'edit.php?post_type=' . Mapping_CPT::POST_TYPE ) ); ?>"><?php esc_html_e( 'Manage form mappings', 'mappings-for-wealthbox' ); ?></a></li>
				<li><a href="<?php echo esc_url( admin_url( 'admin.php?page=wbm-settings' ) ); ?>"><?php esc_html_e( 'Settings (token, base URL)', 'mappings-for-wealthbox' ); ?></a></li>
			</ul>
		</div>
		<?php
	}
		/**
	 * Rename the auto-generated first submenu to "Mappings".
	 */
	public function relabel_first_submenu(): void {
		global $submenu;
		$parent = 'edit.php?post_type=' . Mapping_CPT::POST_TYPE;
		if ( isset( $submenu[ $parent ][0][0] ) ) {
			$submenu[ $parent ][0][0] = __( 'Mappings', 'mappings-for-wealthbox' );
		}
	}
}
