<?php
/**
 * Mappings for Wealthbox custom post type.
 *
 * @package MappingsForWealthbox
 */

namespace MappingsForWealthbox\Admin;

/**
 * Registers the mapping CPT, the Duplicate row action, and helpers for reading
 * a form's saved mapping.
 */
class Mapping_CPT {

	public const POST_TYPE = 'wbm_mapping';

	public const META_FORM_ID     = '_wbm_form_id';
	public const META_ACTION      = '_wbm_action';
	public const META_MATCH_FIELD = '_wbm_match_field';
	public const META_MATCH_TYPE  = '_wbm_match_type';
	public const META_FIELD_MAP   = '_wbm_field_map';

	public function __construct() {
		add_action( 'init', [ $this, 'register' ] );
		add_filter( 'post_row_actions', [ $this, 'add_duplicate_action' ], 10, 2 );
		add_action( 'admin_action_wbm_duplicate_mapping', [ $this, 'handle_duplicate' ] );

		/**
		 * Add these to Mapping_CPT::__construct().
		 */
		add_filter( 'manage_' . self::POST_TYPE . '_posts_columns', [ $this, 'columns' ] );
		add_action( 'manage_' . self::POST_TYPE . '_posts_custom_column', [ $this, 'render_column' ], 10, 2 );
		add_filter( 'manage_edit-' . self::POST_TYPE . '_sortable_columns', [ $this, 'sortable_columns' ] );
		add_action( 'pre_get_posts', [ $this, 'sort_by_form' ] );
	}


	public function columns( array $columns ): array {
	$new = [];
	foreach ( $columns as $key => $label ) {
		$new[ $key ] = $label;
		if ( 'title' === $key ) {
			$new['wbm_form'] = __( 'Gravity Form', 'mappings-for-wealthbox' );
		}
	}
	return $new;
}
 
/**
 * Render the Gravity Form name (centered) for each row.
 */
public function render_column( string $column, int $post_id ): void {
	if ( 'wbm_form' !== $column ) {
		return;
	}
 
	$form_id = (int) get_post_meta( $post_id, self::META_FORM_ID, true );
	$name    = '&mdash;';
 
	if ( $form_id && class_exists( 'GFAPI' ) ) {
		$form = \GFAPI::get_form( $form_id );
		if ( $form && ! empty( $form['title'] ) ) {
			$name = esc_html( $form['title'] );
		}
	}
 
	printf( '<div style="text-align:left;">%s</div>', $name ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
}
 
/**
 * Make the column sortable (sorts by the stored form ID meta).
 */
public function sortable_columns( array $columns ): array {
	$columns['wbm_form'] = 'wbm_form';
	return $columns;
}
 
/**
 * Apply the meta-based sort in the admin list.
 */
public function sort_by_form( \WP_Query $query ): void {
	if ( ! is_admin() || ! $query->is_main_query() ) {
		return;
	}
 
	if ( self::POST_TYPE !== $query->get( 'post_type' ) ) {
		return;
	}
 
	if ( 'wbm_form' === $query->get( 'orderby' ) ) {
		$query->set( 'meta_key', self::META_FORM_ID );
		$query->set( 'orderby', 'meta_value_num' );
	}
}

	/**
	 * Register the CPT (non-public, admin-only, shown under the Wealthbox menu).
	 */
	public function register(): void {
		register_post_type(
			self::POST_TYPE,
			[
				'labels'          => [
					'name'          => __( 'Mappings for Wealthbox', 'mappings-for-wealthbox' ),
					'singular_name' => __( 'Wealthbox Mapping', 'mappings-for-wealthbox' ),
					'add_new_item'  => __( 'Add New Mapping', 'mappings-for-wealthbox' ),
					'edit_item'     => __( 'Edit Mapping', 'mappings-for-wealthbox' ),
					'new_item'      => __( 'New Mapping', 'mappings-for-wealthbox' ),
					'not_found'     => __( 'No mappings yet.', 'mappings-for-wealthbox' ),
					'menu_name'     => __( 'Mappings', 'mappings-for-wealthbox' ),
				],
				'public'          => false,
				'show_ui'         => true,
				// 'show_in_menu'    => true,
				'show_in_menu'    => 'edit.php?post_type=' . self::POST_TYPE,
				'show_in_rest'    => false,
				'supports'        => [ 'title' ],
				'capability_type' => 'post',
				'map_meta_cap'    => true,
				'menu_position'   => 20,
			]
		);
	}

	/**
	 * Add a "Duplicate" link to each mapping row.
	 *
	 * @param array    $actions Existing row actions.
	 * @param \WP_Post $post    Current post.
	 * @return array
	 */
	public function add_duplicate_action( array $actions, $post ): array {
		if ( self::POST_TYPE !== $post->post_type || ! current_user_can( 'edit_posts' ) ) {
			return $actions;
		}

		$url = wp_nonce_url(
			admin_url( 'admin.php?action=wbm_duplicate_mapping&post=' . $post->ID ),
			'wbm_duplicate_' . $post->ID
		);

		$actions['wbm_duplicate'] = sprintf(
			'<a href="%s">%s</a>',
			esc_url( $url ),
			esc_html__( 'Duplicate', 'mappings-for-wealthbox' )
		);

		return $actions;
	}

	/**
	 * Clone a mapping post (with all its meta) as a new draft.
	 */
	public function handle_duplicate(): void {
		$post_id = isset( $_GET['post'] ) ? absint( $_GET['post'] ) : 0;

		if ( ! $post_id || ! current_user_can( 'edit_posts' ) ) {
			wp_die( esc_html__( 'You are not allowed to duplicate this mapping.', 'mappings-for-wealthbox' ) );
		}

		check_admin_referer( 'wbm_duplicate_' . $post_id );

		$original = get_post( $post_id );
		if ( ! $original || self::POST_TYPE !== $original->post_type ) {
			wp_die( esc_html__( 'Invalid mapping.', 'mappings-for-wealthbox' ) );
		}

		$new_id = wp_insert_post(
			[
				'post_type'   => self::POST_TYPE,
				'post_status' => 'draft',
				/* translators: %s: original mapping title. */
				'post_title'  => sprintf( __( '%s (copy)', 'mappings-for-wealthbox' ), $original->post_title ),
			],
			true
		);

		if ( is_wp_error( $new_id ) ) {
			wp_die( esc_html( $new_id->get_error_message() ) );
		}

		foreach ( [ self::META_FORM_ID, self::META_ACTION, self::META_MATCH_FIELD, self::META_MATCH_TYPE, self::META_FIELD_MAP ] as $key ) {
			$value = get_post_meta( $post_id, $key, true );
			if ( '' !== $value ) {
				update_post_meta( $new_id, $key, $value );
			}
		}

		wp_safe_redirect( admin_url( 'post.php?action=edit&post=' . $new_id ) );
		exit;
	}

	/**
	 * Find the published mapping config for a Gravity Form.
	 *
	 * Returns the most recently published mapping when more than one targets the
	 * same form. Null when there is no mapping.
	 *
	 * @param int $form_id GF form ID.
	 * @return array{form_id:int,action:string,match_field:string,match_type:string,field_map:array}|null
	 */
	public static function get_mapping_for_form( int $form_id ): ?array {
		if ( $form_id <= 0 ) {
			return null;
		}

		$posts = get_posts(
			[
				'post_type'      => self::POST_TYPE,
				'post_status'    => 'publish',
				'posts_per_page' => 1,
				'orderby'        => 'date',
				'order'          => 'DESC',
				'no_found_rows'  => true,
				'meta_key'       => self::META_FORM_ID, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				'meta_value'     => (string) $form_id,  // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
				'fields'         => 'ids',
			]
		);

		if ( empty( $posts ) ) {
			return null;
		}

		return self::read( (int) $posts[0] );
	}

	/**
	 * Read a mapping post's config into an array.
	 *
	 * @param int $post_id Mapping post ID.
	 * @return array{form_id:int,action:string,match_field:string,match_type:string,field_map:array}
	 */
	public static function read( int $post_id ): array {
		$map = get_post_meta( $post_id, self::META_FIELD_MAP, true );

		return [
			'form_id'     => (int) get_post_meta( $post_id, self::META_FORM_ID, true ),
			'action'      => (string) ( get_post_meta( $post_id, self::META_ACTION, true ) ?: 'create' ),
			'match_field' => (string) get_post_meta( $post_id, self::META_MATCH_FIELD, true ),
			'match_type'  => (string) ( get_post_meta( $post_id, self::META_MATCH_TYPE, true ) ?: 'email' ),
			'field_map'   => is_array( $map ) ? $map : [],
		];
	}
}
