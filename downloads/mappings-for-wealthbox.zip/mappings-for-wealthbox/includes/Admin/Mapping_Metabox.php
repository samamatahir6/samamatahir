<?php
/**
 * Mapping metabox (form picker + two-column field map).
 *
 * @package MappingsForWealthbox
 */

namespace MappingsForWealthbox\Admin;

use MappingsForWealthbox\Fields\Form_Fields;
use MappingsForWealthbox\Fields\Native_Fields;

/**
 * Renders and saves the mapping UI on a Wealthbox Mapping post.
 *
 * The free plugin maps to the native Contact fields only. Add-ons extend the
 * screen through wbm_metabox_rows, wbm_save_mapping, wbm_target_groups and
 * wbm_suggest_target.
 */
class Mapping_Metabox {

	private const NONCE = 'wbm_mapping_nonce';

	public function __construct() {
		add_action( 'add_meta_boxes', [ $this, 'add' ] );
		add_action( 'save_post_' . Mapping_CPT::POST_TYPE, [ $this, 'save' ], 10, 2 );
		add_action( 'admin_enqueue_scripts', [ $this, 'assets' ] );
		add_action( 'wp_ajax_wbm_form_fields', [ $this, 'ajax_form_fields' ] );
	}

	/**
	 * Register the metaboxes.
	 */
	public function add(): void {
		add_meta_box(
			'wbm_mapping_config',
			__( 'Wealthbox Mapping', 'mappings-for-wealthbox' ),
			[ $this, 'render' ],
			Mapping_CPT::POST_TYPE,
			'normal',
			'high'
		);
	}

	/**
	 * Enqueue admin JS/CSS only on the mapping edit screen.
	 *
	 * @param string $hook Current admin page hook.
	 */
	public function assets( string $hook ): void {
		$screen = get_current_screen();
		if ( ! $screen || Mapping_CPT::POST_TYPE !== $screen->post_type ) {
			return;
		}

		// Select2 (searchable dropdowns).
		wp_enqueue_style( 'wbm-select2', WBM_URL .'assets/select2/select2.min.css', [], '4.0.13' );
		wp_enqueue_script( 'wbm-select2', WBM_URL .'assets/select2/select2.min.js', [ 'jquery' ], '4.0.13', true );


		wp_enqueue_style( 'wbm-admin', WBM_URL . 'assets/admin.css', [], WBM_VERSION );
		wp_enqueue_script( 'wbm-admin', WBM_URL . 'assets/admin.js', [ 'jquery' ], time(), true );
		wp_localize_script(
			'wbm-admin',
			'wbmAdmin',
			[
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'wbm_form_fields' ),
			]
		);
	}

	/**
	 * Render the metabox.
	 *
	 * @param \WP_Post $post Current post.
	 */
	public function render( $post ): void {
		wp_nonce_field( self::NONCE, self::NONCE );
		$mapping = Mapping_CPT::read( $post->ID );
		$forms   = $this->get_forms();
		?>
		<table class="form-table" role="presentation">
			<tr>
				<th scope="row"><label for="wbm_form_id"><?php esc_html_e( 'Gravity Form', 'mappings-for-wealthbox' ); ?></label></th>
				<td>
					<select id="wbm_form_id" name="wbm_form_id">
						<option value="0"><?php esc_html_e( '— Select a form —', 'mappings-for-wealthbox' ); ?></option>
						<?php foreach ( $forms as $form ) : ?>
							<option value="<?php echo esc_attr( $form['id'] ); ?>" <?php selected( (int) $mapping['form_id'], (int) $form['id'] ); ?>>
								<?php echo esc_html( $form['title'] ); ?>
							</option>
						<?php endforeach; ?>
					</select>
				</td>
			</tr>
			<?php
			/**
			 * Add-on rows (action, match field, ...) inside the metabox table.
			 *
			 * @param array    $mapping Saved mapping config.
			 * @param \WP_Post $post    Current post.
			 */
			do_action( 'wbm_metabox_rows', $mapping, $post );
			?>
			<tr>
				<th scope="row"><?php esc_html_e( 'Hidden fields', 'mappings-for-wealthbox' ); ?></th>
				<td>
					<label>
						<input type="checkbox" id="wbm_show_hidden">
						<?php esc_html_e( 'Show hidden fields', 'mappings-for-wealthbox' ); ?>
					</label>
					<p class="description"><?php esc_html_e( 'Reveal hidden Gravity Forms fields (userId, UTM, tracking) in the list below.', 'mappings-for-wealthbox' ); ?></p>
				</td>
			</tr>
		</table>

		<h3><?php esc_html_e( 'Field mapping', 'mappings-for-wealthbox' ); ?></h3>
		<p class="description"><?php esc_html_e( 'Left: Gravity Form fields. Right: the Wealthbox field each one is sent to.', 'mappings-for-wealthbox' ); ?></p>

		<div id="wbm-map-table" data-saved="<?php echo esc_attr( wp_json_encode( $mapping['field_map'] ) ); ?>">
			<?php
			if ( (int) $mapping['form_id'] > 0 ) {
				echo $this->render_map_rows( (int) $mapping['form_id'], $mapping['field_map'] ); // phpcs:ignore WordPress.Security.EscapingOutput.OutputNotEscaped -- Built with escaped internals.
			} else {
				echo '<p class="wbm-empty">' . esc_html__( 'Select a form to load its fields.', 'mappings-for-wealthbox' ) . '</p>';
			}
			?>
		</div>
		<?php
	}

	/**
	 * AJAX: return the mapping table for a selected form.
	 */
	public function ajax_form_fields(): void {
		check_ajax_referer( 'wbm_form_fields', 'nonce' );

		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_send_json_error( [ 'message' => __( 'Insufficient permissions.', 'mappings-for-wealthbox' ) ], 403 );
		}

		$form_id = isset( $_POST['form_id'] ) ? absint( $_POST['form_id'] ) : 0;
		if ( ! $form_id ) {
			wp_send_json_error( [ 'message' => __( 'No form selected.', 'mappings-for-wealthbox' ) ] );
		}

		wp_send_json_success( [ 'html' => $this->render_map_rows( $form_id, [] ) ] );
	}

	/**
	 * Dropdown groups for the Wealthbox side: key => [ label, options ].
	 *
	 * The free plugin offers the native Contact fields; add-ons append groups
	 * (e.g. custom fields) through the wbm_target_groups filter.
	 *
	 * @return array<string,array{label:string,options:array<string,string>}>
	 */
	private function target_groups(): array {
		$groups = [
			'native' => [
				'label'   => __( 'Wealthbox native fields', 'mappings-for-wealthbox' ),
				'options' => Native_Fields::all(),
			],
		];

		/**
		 * Filter the groups shown in the Wealthbox field dropdown.
		 *
		 * @param array $groups key => [ 'label' => string, 'options' => [ id => label ] ].
		 */
		return (array) apply_filters( 'wbm_target_groups', $groups );
	}

	/**
	 * Build the two-column mapping table for a form.
	 *
	 * @param int   $form_id GF form ID.
	 * @param array $saved   Saved gf_key => wb_field_id map.
	 * @return string HTML.
	 */
	private function render_map_rows( int $form_id, array $saved ): string {
		$gf_fields = Form_Fields::flatten( $form_id );
		$groups    = $this->target_groups();

		if ( empty( $gf_fields ) ) {
			return '<p class="wbm-empty">' . esc_html__( 'This form has no fields, or Gravity Forms is unavailable.', 'mappings-for-wealthbox' ) . '</p>';
		}

		ob_start();
		?>
		<table class="widefat striped wbm-map">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Gravity Form field', 'mappings-for-wealthbox' ); ?></th>
					<th><?php esc_html_e( 'Wealthbox field', 'mappings-for-wealthbox' ); ?></th>
				</tr>
			</thead>
			<tbody>
			<?php foreach ( $gf_fields as $gf ) : ?>
				<?php
				$key        = (string) $gf['key'];
				/**
				 * Pre-selected Wealthbox target for a GF field when nothing is saved.
				 *
				 * @param int|string $selected 0 for none, else a target id.
				 * @param string     $label    Gravity Forms field label.
				 */
				$selected   = isset( $saved[ $key ] ) ? (string) $saved[ $key ] : (string) apply_filters( 'wbm_suggest_target', 0, $gf['label'] );
				$input_name = 'wbm_field_map[' . esc_attr( $key ) . ']';
				?>

				<tr class="<?php echo ! empty( $gf['is_hidden'] ) ? 'wbm-row-hidden' : ''; ?>">
					<td>
						<strong><?php echo esc_html( $gf['label'] ); ?></strong>
						<?php if ( ! empty( $gf['nested'] ) ) : ?>
							<span class="wbm-nested-tag"><?php esc_html_e( 'nested', 'mappings-for-wealthbox' ); ?></span>
						<?php endif; ?>
						<code><?php echo esc_html( $key ); ?></code>
					</td>
					<td>
						<select name="<?php echo esc_attr( $input_name ); ?>" class="wbm-wb-field">
							<option value="0"><?php esc_html_e( '— Not mapped —', 'mappings-for-wealthbox' ); ?></option>
							<?php foreach ( $groups as $group ) : ?>
								<optgroup label="<?php echo esc_attr( $group['label'] ); ?>">
									<?php foreach ( $group['options'] as $option_id => $option_label ) : ?>
										<option value="<?php echo esc_attr( (string) $option_id ); ?>" <?php selected( $selected, (string) $option_id ); ?>>
											<?php echo esc_html( $option_label ); ?>
										</option>
									<?php endforeach; ?>
								</optgroup>
							<?php endforeach; ?>
						</select>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * Save the mapping config.
	 *
	 * @param int      $post_id Post ID.
	 * @param \WP_Post $post    Post object.
	 */
	public function save( int $post_id, $post ): void {
		if ( ! isset( $_POST[ self::NONCE ] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST[ self::NONCE ] ) ), self::NONCE ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		update_post_meta( $post_id, Mapping_CPT::META_FORM_ID, absint( $_POST['wbm_form_id'] ?? 0 ) );

		$raw_map = isset( $_POST['wbm_field_map'] ) && is_array( $_POST['wbm_field_map'] ) ? wp_unslash( $_POST['wbm_field_map'] ) : [];
		$clean   = [];
		foreach ( $raw_map as $gf_key => $wb_id ) {
			$wb_id = sanitize_text_field( (string) $wb_id );
			if ( '0' === $wb_id || '' === $wb_id ) {
				continue; // Unmapped.
			}
			// Native ids stay as strings ("native:email"); custom ids as numeric strings.
			$clean[ sanitize_text_field( (string) $gf_key ) ] = $wb_id;
		}
		update_post_meta( $post_id, Mapping_CPT::META_FIELD_MAP, $clean );

		/**
		 * Let add-ons save their own mapping fields (nonce and capability already verified).
		 *
		 * @param int $post_id Mapping post ID.
		 */
		do_action( 'wbm_save_mapping', $post_id );
	}

	/**
	 * List available Gravity Forms.
	 *
	 * @return array<int,array{id:int,title:string}>
	 */
	private function get_forms(): array {
		if ( ! class_exists( '\GFAPI' ) ) {
			return [];
		}

		$forms = \GFAPI::get_forms();
		$out   = [];
		foreach ( (array) $forms as $form ) {
			$out[] = [
				'id'    => (int) $form['id'],
				'title' => (string) $form['title'],
			];
		}
		return $out;
	}
}
